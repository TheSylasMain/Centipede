using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Centipede_Spider
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private GraphicsDeviceManager graphics;//screen is 1000 * 800
        private SpriteBatch spriteBatch;
        //private double x, y, changeX, changeY, oldChangeX;
        //private Rectangle pos, spiderRect;
        //private int width, height;
        private Texture2D spriteSheet;//Sprites are 15*8, with a one pixel barrier in between;
                              //The sheet is an entire 135*8;
        //private Random r;
        private Spider spider;
        public Game1()
        {
            
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            Window.AllowUserResizing = true;
            graphics.PreferredBackBufferWidth = 1000;
            graphics.PreferredBackBufferHeight = 800;
            graphics.ApplyChanges();
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            
            // TODO: Add your initialization logic here

            /**There are mutliple cases of randomized movement and placement**/
            //r = new Random();


            ///**These are for changing the width and height of the spider, in case it needs resizing**/
            //width = 15*3; 
            //height = 8*3;


            ///**This  controls whether or not the spider will spawn on the left side, or right side**/
            //if (r.Next(2)==0)
            //{

            //    x = 0;
            //    y = GraphicsDevice.Viewport.Height * (4 / 5.0) - height;
            //}
            //else
            //{ 
            //        x = GraphicsDevice.Viewport.Width - width;
            //        y = GraphicsDevice.Viewport.Height * (4 / 5.0) - height;
            //}


            ///**This is the rectangle that is displayed with the spider**/
            //pos = new Rectangle((int)x, (int)y, width, height);

            ///**This is the main rectangle for the spider's textures**/
            //spiderRect = new Rectangle(0, 0, 15, 8);

            //changeX = 2;
            //changeY = 2;

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteSheet = Content.Load<Texture2D>("spiderTrans");
            
            /**Spider is made here**/
            spider = new Spider(graphics, spriteSheet);


            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();
            spider.Update(graphics, gameTime);
            // TODO: Add your update logic here

            //int time = gameTime.TotalGameTime.Milliseconds; /**This is my timer, to let me see how long the game has been running**/

            ///**This controls the texture of the spider, animating it**/
            //if (time % 100 == 0)
            //{
            //    spiderRect.X+=17;
            //    if (spiderRect.X > 130)
            //        spiderRect.X = 0;                
            //}


            ///**This is what makes the spider randomly change from moving across the screen, to a period of time where it strictly moves up and down**/
            //if (time % 400 == 0)
            //{
            //    if (r.Next(2) == 0)
            //    {
            //        if (changeX == 0)
            //            changeX = oldChangeX;
            //    }
            //}
            //if (time % 2500 == 0)
            //{
            //    if (r.Next(2) == 0)
            //    {
            //        if(changeX!=0)
            //         oldChangeX = changeX;
            //        changeX = 0;
            //    }
                
            //}



            ///**This part of the code controls the base movement, in order to bounce off walls, change direction, etc.**/
            //if (pos.X < 0 || pos.X > GraphicsDevice.Viewport.Width-pos.Width)
            //    changeX *= -1;
            //if (pos.Y < GraphicsDevice.Viewport.Height * (4 / 5.0) - height || pos.Y > GraphicsDevice.Viewport.Height-pos.Height)
            //    changeY *= -1;
            //x += changeX;
            //y += changeY;
            //pos.X = (int)x;
            //pos.Y = (int)y;

            

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            spriteBatch.Draw(spriteSheet, spider.getPos(), spider.getSpiderTexture(), Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }

        /**This method is for eating mushrooms**/


        //public void checkMushroom(List<Mushroom> mushrooms)
        //{
        //    for (int i = 0; i < mushrooms.Count; i++)
        //    {
        //        if (pos.Intersects(mushrooms.ElementAt(i).getPosition()))
        //        {
        //            mushrooms.RemoveAt(i);
        //        }
        //    }
        //}
    }
}
